#include "WalletServiceErrorCategory.h"

namespace CryptoNote {
namespace error {

WalletServiceErrorCategory WalletServiceErrorCategory::INSTANCE;

}
}
