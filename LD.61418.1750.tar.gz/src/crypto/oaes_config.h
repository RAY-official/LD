#ifndef _OAES_CONFIG_H
#define _OAES_CONFIG_H

#ifdef __cplusplus 
extern "C" {
#endif

//#ifndef OAES_HAVE_ISAAC
//#define OAES_HAVE_ISAAC 1
//#endif // OAES_HAVE_ISAAC

//#ifndef OAES_DEBUG
//#define OAES_DEBUG 0
//#endif // OAES_DEBUG

#ifdef __cplusplus 
}
#endif

#endif // _OAES_CONFIG_H
