// Copyright (c) 2012-2018
/* 
==================Core Developer==================
The Bitcoin Developer
The Dark/Dash Developer
The CryptoNote Developer
The Bytecoin Developer
The Sumo Developer
The Kabowanec Developer
The Parsi Developer
The XDN Developer
The Royalties Developer
==================Add On Developer================
[ ] developers
- Sora as Core Platform
- Shiro as Compiler and Bug Solver
- Homdx as Docker Engineer[unactive]
- James as GUI Specialist[unactive]
- Shaik Vahid as Windows Compiler
- Mahadi as Windows Developer
=================External Developer===============
- Aiwe K as CN-7 impelemented algorithm
- Jaggerman as Difficulty LWMA Specialist 
====================Algorithm=====================
Brian Gladman, Worcester, UK.[aesb]
http://131002.net/blake/[blake]
HAMC[blake]
D. J. Bernstein[chacha]
Thomas Krinninger[groestl]
Soeren S. Thomsen and Krystian Matusiewicz[groestl]
Nabil S. Al Ramli, www.nalramli.com[openaes]
Markku-Juhani O. Saarinen <mjos@iki.fi>[keccak]
Doug Whiting, 2008[skein]
=================Platform Developer===============
Christopher M. Kohlhoff (chris at kohlhoff dot com)
Andrey N.Sabelnikov, www.sabelnikov.net
====================Support=======================

you can added manual
*/
